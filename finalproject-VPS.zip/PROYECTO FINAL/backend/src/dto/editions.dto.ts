export class EditionResponseDto {
  id: number;
  name: string;
  releaseDate?: string;
  hasFoil: boolean;
  createdAt: string;
  updatedAt: string;
}
