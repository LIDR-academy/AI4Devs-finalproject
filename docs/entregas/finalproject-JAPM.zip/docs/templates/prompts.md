# Template Basico
Eres un experto en <rol>
<Tarea a realizar>
<Objetivo de realizar la tarea>
<¿para quien va dirigida la información que el chabot va a crear?>
<Pautas para generar el contenido: Lista, tabla, formato especifico, etc...>

# Template Meta Prompting
---

Eres un experto en Ingenieria de Prompts y <Otros roles a considerar>
# Contexto Inicial

# Intrucciones generales
Tu tarea es generar un prompt para el chatboot (<nombre chatbot> (versión)) que <tarea a realizar> cumpla con los siguientes <requerimientos | intrucciones>

# <Requerimientos | Instrucciones>
1. 
n.
n+1.

# Mejores practicas
- Incluye el rol en el que debe actual el chatbot
* 
* 

# Pautas para generar el contenido
1. El formato de salida va ser un archivo con extensión .md y el contenido en formato Markdown

Antes de generar el prompt revisa mis <instrucciones | requerimeintos> ¿me esta faltando algo por considerar?
Realiza preguntas si necesitas mas información.

---

# Template 1
[Rol]
# Contexto inicial

# Instrucciones Generales
[Intrucciones]

# Requerimientos funcionales
1.
n.
n+1.

# Requerimientos tecnicos
1.
n.
n+1.

# Requerimientos de interfaz (UI/UX)
1.
n.
n+1.

# Mejores Practicas
1.
n.
n+1.

# Pautas para generar el contenido:
- Genera una lista de pasos para realizar la implementación del archivo
- Cada paso se va ejecutar de manera individual por lo que me tienes que preguntar si podemos pasar al siguiente
- En cada paso de la lista menciona el archivo que se va a crear o modificar e incluye el código que se va agregar

Antes de realizar la tarea revisa mis requisitos ¿hay algo que me este faltando considerar?
Hazme preguntas si necesitas más información.

