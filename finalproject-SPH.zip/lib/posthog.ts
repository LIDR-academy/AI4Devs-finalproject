import posthog from 'posthog-js';

let posthogInitialized = false;

export function initPostHog() {
  if (typeof window !== 'undefined' && !posthogInitialized) {
    const posthogKey = process.env.NEXT_PUBLIC_POSTHOG_KEY;
    const posthogHost = process.env.NEXT_PUBLIC_POSTHOG_HOST;

    if (posthogKey && posthogHost) {
      posthog.init(posthogKey, {
        api_host: posthogHost,
        capture_pageview: true,
        capture_pageleave: true,
      });
      posthogInitialized = true;
    }
  }
}

export function trackEvent(eventName: string, properties?: Record<string, any>) {
  if (typeof window !== 'undefined' && posthogInitialized) {
    posthog.capture(eventName, properties);
  }
}

// Event types for better type safety
export const EVENTS = {
  REWRITE_SUBMITTED: 'rewrite_submitted',
  REWRITE_SUCCESS: 'rewrite_success',
  REWRITE_ERROR: 'rewrite_error',
  COPY_RESULT: 'copy_result',
  REGENERATE: 'regenerate',
  RATE_LIMIT_REACHED: 'rate_limit_reached',
} as const;

export default posthog;
