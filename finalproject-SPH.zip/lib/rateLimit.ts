import { Redis } from '@upstash/redis';

// Configuración de Redis
const redis = Redis.fromEnv();

export interface RateLimitResult {
  success: boolean;
  limit: number;
  remaining: number;
  reset: number;
}

export async function rateLimit(ip: string): Promise<RateLimitResult> {
  const limit = parseInt(process.env.RATE_LIMIT_REQUESTS || '10');
  const window = parseInt(process.env.RATE_LIMIT_WINDOW || '86400'); // 24 hours in seconds
  
  const key = `rate_limit:${ip}`;
  const now = Math.floor(Date.now() / 1000);
  const windowStart = now - window;

  try {
    // Get current count for this IP
    const current = await redis.get(key);
    const currentCount = current ? parseInt(current.toString()) : 0;

    if (currentCount >= limit) {
      // Get TTL to know when the limit resets
      const ttl = await redis.ttl(key);
      const resetTime = ttl > 0 ? now + ttl : now + window;

      return {
        success: false,
        limit,
        remaining: 0,
        reset: resetTime,
      };
    }

    // Increment counter
    await redis.incr(key);
    
    // Set expiration if this is the first request in the window
    if (currentCount === 0) {
      await redis.expire(key, window);
    }

    return {
      success: true,
      limit,
      remaining: limit - currentCount - 1,
      reset: now + window,
    };
  } catch (error) {
    console.error('Rate limit error:', error);
    // In case of Redis error, allow the request but log the error
    return {
      success: true,
      limit,
      remaining: limit - 1,
      reset: now + window,
    };
  }
}

export async function getRemainingUses(ip: string): Promise<number> {
  const limit = parseInt(process.env.RATE_LIMIT_REQUESTS || '10');
  const key = `rate_limit:${ip}`;

  try {
    const current = await redis.get(key);
    const currentCount = current ? parseInt(current.toString()) : 0;
    return Math.max(0, limit - currentCount);
  } catch (error) {
    console.error('Error getting remaining uses:', error);
    return limit; // Return full limit if there's an error
  }
}
