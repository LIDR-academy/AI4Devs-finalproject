import type { NextApiRequest, NextApiResponse } from 'next';
import { getRemainingUses } from '@/lib/rateLimit';

interface RemainingUsesResponse {
  remaining: number;
  limit: number;
}

// Get client IP address
function getClientIP(req: NextApiRequest): string {
  const forwarded = req.headers['x-forwarded-for'];
  const ip = forwarded 
    ? (Array.isArray(forwarded) ? forwarded[0] : forwarded.split(',')[0])
    : req.connection.remoteAddress || 'unknown';
  return ip;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<RemainingUsesResponse>
) {
  // Only allow GET requests
  if (req.method !== 'GET') {
    return res.status(405).end();
  }

  try {
    const clientIP = getClientIP(req);
    const remaining = await getRemainingUses(clientIP);
    const limit = parseInt(process.env.RATE_LIMIT_REQUESTS || '10');

    return res.status(200).json({
      remaining,
      limit,
    });
  } catch (error) {
    console.error('Error getting remaining uses:', error);
    const limit = parseInt(process.env.RATE_LIMIT_REQUESTS || '10');
    
    return res.status(200).json({
      remaining: limit,
      limit,
    });
  }
}
