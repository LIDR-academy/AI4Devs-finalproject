import type { NextApiRequest, NextApiResponse } from 'next';
import OpenAI from 'openai';
import { rateLimit } from '@/lib/rateLimit';
import { createRewritePrompt } from '@/utils/rewritePrompt';

// Initialize OpenAI client
const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

interface RewriteRequest {
  text: string;
  tone: 'clear' | 'formal' | 'empathetic' | 'persuasive';
}

interface RewriteResponse {
  success: boolean;
  rewrittenText?: string;
  error?: string;
  rateLimitInfo: {
    remaining: number;
    limit: number;
    reset: number;
  };
}

// Get client IP address
function getClientIP(req: NextApiRequest): string {
  const forwarded = req.headers['x-forwarded-for'];
  const ip = forwarded 
    ? (Array.isArray(forwarded) ? forwarded[0] : forwarded.split(',')[0])
    : req.connection.remoteAddress || 'unknown';
  return ip;
}

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<RewriteResponse>
) {
  // Only allow POST requests
  if (req.method !== 'POST') {
    return res.status(405).json({
      success: false,
      error: 'Method not allowed',
      rateLimitInfo: { remaining: 0, limit: 10, reset: 0 }
    });
  }

  try {
    const { text, tone }: RewriteRequest = req.body;

    // Validate input
    if (!text || !tone) {
      return res.status(400).json({
        success: false,
        error: 'Missing text or tone',
        rateLimitInfo: { remaining: 0, limit: 10, reset: 0 }
      });
    }

    // Validate text length (max 2000 characters)
    if (text.length > 2000) {
      return res.status(400).json({
        success: false,
        error: 'Text exceeds 2000 character limit',
        rateLimitInfo: { remaining: 0, limit: 10, reset: 0 }
      });
    }

    // Validate tone
    const validTones = ['clear', 'formal', 'empathetic', 'persuasive'];
    if (!validTones.includes(tone)) {
      return res.status(400).json({
        success: false,
        error: 'Invalid tone selected',
        rateLimitInfo: { remaining: 0, limit: 10, reset: 0 }
      });
    }

    // Check rate limit
    const clientIP = getClientIP(req);
    const rateLimitResult = await rateLimit(clientIP);

    if (!rateLimitResult.success) {
      return res.status(429).json({
        success: false,
        error: 'Rate limit exceeded. Try again tomorrow.',
        rateLimitInfo: {
          remaining: rateLimitResult.remaining,
          limit: rateLimitResult.limit,
          reset: rateLimitResult.reset
        }
      });
    }

    // Create prompt for OpenAI
    const prompt = createRewritePrompt({ text, tone });

    // Call OpenAI API
    const completion = await openai.chat.completions.create(prompt);

    const rewrittenText = completion.choices[0]?.message?.content;

    if (!rewrittenText) {
      throw new Error('No response from OpenAI');
    }

    // Return success response
    return res.status(200).json({
      success: true,
      rewrittenText: rewrittenText.trim(),
      rateLimitInfo: {
        remaining: rateLimitResult.remaining,
        limit: rateLimitResult.limit,
        reset: rateLimitResult.reset
      }
    });

  } catch (error) {
    console.error('Rewrite API error:', error);
    
    return res.status(500).json({
      success: false,
      error: 'Error processing your email. Please try again later.',
      rateLimitInfo: { remaining: 0, limit: 10, reset: 0 }
    });
  }
}
