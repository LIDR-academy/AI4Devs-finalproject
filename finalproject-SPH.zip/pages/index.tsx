import { useState, useEffect } from 'react';
import Head from 'next/head';
import Image from 'next/image';
import { initPostHog, trackEvent, EVENTS } from '@/lib/posthog';

interface RewriteResponse {
  success: boolean;
  rewrittenText?: string;
  error?: string;
  rateLimitInfo: {
    remaining: number;
    limit: number;
    reset: number;
  };
}

const tones = [
  { id: 'clear', label: 'Clear', description: 'Simple and direct' },
  { id: 'formal', label: 'Formal', description: 'Professional and respectful' },
  { id: 'empathetic', label: 'Empathetic', description: 'Understanding and considerate' },
  { id: 'persuasive', label: 'Persuasive', description: 'Convincing and motivating' },
] as const;

export default function Home() {
  const [inputText, setInputText] = useState('');
  const [selectedTone, setSelectedTone] = useState<string>('clear');
  const [result, setResult] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [message, setMessage] = useState<{ text: string; type: 'success' | 'error' | 'warning' }>({ text: '', type: 'success' });
  const [remainingUses, setRemainingUses] = useState(10);
  const [isEditingResult, setIsEditingResult] = useState(false);

  // Initialize PostHog on mount
  useEffect(() => {
    initPostHog();
  }, []);

  // Fetch remaining uses on mount
  useEffect(() => {
    fetchRemainingUses();
  }, []);

  const fetchRemainingUses = async () => {
    try {
      const response = await fetch('/api/remaining-uses');
      if (response.ok) {
        const data = await response.json();
        setRemainingUses(data.remaining);
      }
    } catch (error) {
      console.error('Error fetching remaining uses:', error);
    }
  };

  const handleImprove = async () => {
    if (!inputText.trim()) {
      setMessage({ text: 'Please paste an email to continue.', type: 'error' });
      return;
    }

    if (inputText.length > 2000) {
      setMessage({ text: 'You have exceeded the character limit.', type: 'error' });
      return;
    }

    if (remainingUses <= 0) {
      setMessage({ text: 'You have reached your daily limit.', type: 'warning' });
      return;
    }

    setIsLoading(true);
    setMessage({ text: '', type: 'success' });

    // Track event
    trackEvent(EVENTS.REWRITE_SUBMITTED, {
      tone: selectedTone,
      textLength: inputText.length,
    });

    try {
      const response = await fetch('/api/rewrite', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          text: inputText,
          tone: selectedTone,
        }),
      });

      const data: RewriteResponse = await response.json();

      if (data.success && data.rewrittenText) {
        setResult(data.rewrittenText);
        setRemainingUses(data.rateLimitInfo.remaining);
        setMessage({ text: 'Email improved successfully!', type: 'success' });
        setIsEditingResult(false);
        
        trackEvent(EVENTS.REWRITE_SUCCESS, {
          tone: selectedTone,
          originalLength: inputText.length,
          resultLength: data.rewrittenText.length,
        });
      } else {
        setMessage({ text: data.error || 'Error processing your email.', type: 'error' });
        if (data.rateLimitInfo) {
          setRemainingUses(data.rateLimitInfo.remaining);
        }
        
        trackEvent(EVENTS.REWRITE_ERROR, {
          error: data.error,
          tone: selectedTone,
        });
      }
    } catch (error) {
      setMessage({ text: 'Error processing your email. Please try again later.', type: 'error' });
      trackEvent(EVENTS.REWRITE_ERROR, {
        error: 'Network error',
        tone: selectedTone,
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(result);
      setMessage({ text: 'Copied to clipboard!', type: 'success' });
      trackEvent(EVENTS.COPY_RESULT, {
        textLength: result.length,
      });
    } catch (error) {
      setMessage({ text: 'Failed to copy to clipboard.', type: 'error' });
    }
  };

  const handleRegenerate = async () => {
    if (remainingUses <= 0) {
      setMessage({ text: 'You cannot regenerate more emails today.', type: 'warning' });
      return;
    }

    trackEvent(EVENTS.REGENERATE, {
      tone: selectedTone,
    });

    await handleImprove();
  };

  const getMessageColor = () => {
    switch (message.type) {
      case 'success': return 'text-green-600';
      case 'error': return 'text-red-600';
      case 'warning': return 'text-orange-600';
      default: return 'text-gray-600';
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <Head>
        <title>MailTuner - Improve your emails with AI</title>
        <meta name="description" content="Automatically improve your emails with the right tone - clear, formal, empathetic, or persuasive." />
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <link rel="icon" href="/logo-MailTuner.png" />
      </Head>

      <main className="container mx-auto px-4 py-8 max-w-4xl">
        {/* Header */}
        <header className="text-center mb-12">
          <div className="flex items-center justify-center mb-6">
            <Image
              src="/logo-MailTuner.png"
              alt="MailTuner Logo"
              width={60}
              height={60}
              className="mr-3"
            />
            <h1 className="text-4xl md:text-5xl font-bold font-manrope text-textDark">
              MailTuner
            </h1>
          </div>
          <p className="text-lg md:text-xl text-gray-600 mb-4">
            Improve your emails automatically with the perfect tone
          </p>
          <p className="text-sm text-gray-500">
            You have <span className="font-semibold text-primary">{remainingUses}</span> free improvements left today
          </p>
        </header>

        {/* Main Content */}
        <div className="bg-white rounded-2xl shadow-lg p-6 md:p-8 mb-8">
          {/* Input Section */}
          <div className="mb-8">
            <label htmlFor="email-input" className="block text-lg font-semibold text-textDark mb-3">
              Paste your email here
            </label>
            <textarea
              id="email-input"
              value={inputText}
              onChange={(e) => setInputText(e.target.value)}
              placeholder="Paste your email here..."
              className="w-full h-40 p-4 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-primary focus:border-transparent text-textDark"
              maxLength={2000}
            />
            <div className="flex justify-between items-center mt-2 text-sm text-gray-500">
              <span>{inputText.length} / 2000 characters</span>
              {inputText.length > 1800 && (
                <span className="text-orange-600">Approaching character limit</span>
              )}
            </div>
          </div>

          {/* Tone Selection */}
          <div className="mb-8">
            <label className="block text-lg font-semibold text-textDark mb-4">
              Choose your tone
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {tones.map((tone) => (
                <button
                  key={tone.id}
                  onClick={() => setSelectedTone(tone.id)}
                  className={`p-4 rounded-lg border-2 transition-all duration-200 text-left ${
                    selectedTone === tone.id
                      ? 'border-primary bg-primary bg-opacity-10 text-primary'
                      : 'border-gray-200 hover:border-gray-300 text-textDark'
                  }`}
                >
                  <div className="font-semibold">{tone.label}</div>
                  <div className="text-sm opacity-75">{tone.description}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Action Button */}
          <div className="mb-8">
            <button
              onClick={handleImprove}
              disabled={isLoading || !inputText.trim() || remainingUses <= 0}
              className="w-full md:w-auto px-8 py-4 bg-primary text-white font-semibold rounded-lg hover:bg-primary/90 disabled:bg-gray-300 disabled:cursor-not-allowed transition-colors duration-200 text-lg"
            >
              {isLoading ? 'Improving...' : 'Improve my email'}
            </button>
          </div>

          {/* Status Message */}
          {message.text && (
            <div className={`mb-6 p-4 rounded-lg bg-gray-50 ${getMessageColor()}`}>
              {message.text}
            </div>
          )}

          {/* Result Section */}
          {result && (
            <div className="border-t pt-8">
              <label htmlFor="result-text" className="block text-lg font-semibold text-textDark mb-3">
                Improved email
              </label>
              <textarea
                id="result-text"
                value={result}
                onChange={(e) => {
                  setResult(e.target.value);
                  setIsEditingResult(true);
                }}
                className="w-full h-40 p-4 border border-gray-300 rounded-lg resize-none focus:ring-2 focus:ring-primary focus:border-transparent text-textDark"
              />
              <div className="flex flex-col sm:flex-row gap-3 mt-4">
                <button
                  onClick={handleCopy}
                  className="px-6 py-3 bg-secondary text-white font-semibold rounded-lg hover:bg-secondary/90 transition-colors duration-200"
                >
                  Copy to clipboard
                </button>
                <button
                  onClick={handleRegenerate}
                  disabled={remainingUses <= 0}
                  className="px-6 py-3 border border-primary text-primary font-semibold rounded-lg hover:bg-primary hover:text-white disabled:border-gray-300 disabled:text-gray-300 disabled:cursor-not-allowed transition-colors duration-200"
                >
                  Regenerate ({remainingUses} left)
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <footer className="text-center text-sm text-gray-500 border-t pt-8">
          <div className="flex flex-wrap justify-center gap-6 mb-4">
            <a href="#" className="hover:text-primary transition-colors">Privacy Policy</a>
            <a href="#" className="hover:text-primary transition-colors">Terms of Service</a>
            <a href="#" className="hover:text-primary transition-colors">Cookie Policy</a>
          </div>
          <p>&copy; 2025 MailTuner. Built with ❤️ for better communication.</p>
        </footer>
      </main>
    </div>
  );
}
