/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './pages/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
    './app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        // Paleta de colores específica para MailTuner
        primary: '#4F46E5', // Índigo
        secondary: '#22D3EE', // Cyan claro
        background: '#F9FAFB', // Gris muy claro
        textDark: '#111827', // Gris oscuro
      },
      fontFamily: {
        // Fuentes específicas
        'manrope': ['Manrope', 'sans-serif'], // Logo
        'dmsans': ['DM Sans', 'sans-serif'], // Interfaz
      },
    },
  },
  plugins: [],
}
