export interface RewritePromptParams {
  text: string;
  tone: string;
}

//Version 0.0.1 del prompt:
//errores encontrados: Fallo en el idioma, no solo pone el cuerpo si no que tambien pone sujeto, saludo y despedida.
/*export function createRewritePrompt({ text, tone }: RewritePromptParams) {
  return {
    model: "gpt-4o",
    messages: [
      {
        role: "system" as const,
        content: "Act as an expert assistant in professional email writing. You must respond only with the rewritten text, without explanations, headers, or notes."
      },
      {
        role: "user" as const,
        content: `Take the following message and rewrite it with the indicated tone. Maintain the original content, but improve clarity, structure and style to make it more effective in a professional context.

- Desired tone: ${tone}
- Original text: "${text}"

Rewrite only the text, without adding explanations, headers or notes.`
      }
    ],
    max_tokens: parseInt(process.env.OPENAI_MAX_TOKENS || "500"),
    temperature: 0.7,
  };
}*/

export function createRewritePrompt({ text, tone }: RewritePromptParams) {
  return {
    model: "gpt-4o",
    messages: [
      {
        role: "system" as const,
        content: [
          "You are an expert assistant in professional email writing.",
          "Always maintain the ORIGINAL language of the input text.",
          "Respond ONLY with the REWRITTEN BODY of the email.",
          "Do NOT include subject lines, greetings, sign-offs, or any additional text.",
          "Output plain text only."
        ].join(" ")
      },
      {
        role: "user" as const,
        content: [
          "Rewrite the following email body with the indicated tone.",
          "- Desired tone: " + tone,
          `- Original text: "${text}"`,
          "Return ONLY the rewritten body, without explanations."
        ].join("\n")
      }
    ],
    max_tokens: parseInt(process.env.OPENAI_MAX_TOKENS || "500"),
    temperature: 0.7,
  };
}
